package tests;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;


import pages.LoginPage;
import pages.OrderPage;

public class OrderTests extends BaseTest {
	
    @Test(groups = {"Functional"})
    public void TC_Order_01_AgregarProductoAlCarrito() {
        driver.get("https://demo.evershop.io/account/login");
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("luisdiaz@gmail.com", "Luiz$diAz24"); // Cambiar por credenciales válidas
        

        OrderPage orderPage = new OrderPage(driver);
        orderPage.addProductToCart();
        orderPage.goToCartAndCheckout();
    }
    
    /*
    @Test
    public void TC_Order_02_EliminarProductoDelCarrito() {
        driver.get("https://demo.evershop.io/account/login");
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("luisdiaz@gmail.com", "Luiz$diAz24"); // Cambiar por credenciales válidas
        

        OrderPage orderPage = new OrderPage(driver);
        orderPage.addProductToCart();
        orderPage.goToCartAndCheckout();
        
        
        Assert.assertTrue(orderPage.isProductInCart(), "El producto no se agregó al carrito correctamente.");

        orderPage.deleteProductFromCart();

        Assert.assertTrue(orderPage.isCartEmpty(), "El carrito no quedó vacío después de eliminar el producto.");
    }
    
    */
    
}