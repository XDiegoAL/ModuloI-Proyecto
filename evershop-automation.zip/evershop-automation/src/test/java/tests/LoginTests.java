package tests;


import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import pages.LoginPage;

public class LoginTests extends BaseTest {
	
	
    @Test(groups = {"Functional"})
    public void TC_Login_01_SuccessfulLogin() {

    	driver.findElement(By.name("email")).sendKeys("PedroGarcia@gmail.com");
        driver.findElement(By.name("password")).sendKeys("PedroG4rci@$$");
        driver.findElement(By.xpath("//button[span[text()='SIGN IN']]")).click();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // Esperar que la URL sea la de home
        wait.until(ExpectedConditions.urlToBe("https://demo.evershop.io/"));

        // Verificar el encabezado h1
        WebElement heading = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("//h1[text()='Your Heading Here']")
        ));

        Assert.assertEquals(heading.getText(), "Your Heading Here", "El encabezado no es el esperado después del login.");
    }
    
    
    @Test(groups = {"Functional"})
    public void TC_Login_02_InvalidCredentials() {

        // Intentar hacer login con un email y contraseña incorrectos
        driver.findElement(By.name("email")).sendKeys("PedroGarcia@gmail.com"); // Correo incorrecto
        driver.findElement(By.name("password")).sendKeys("incorrecta123"); // Contraseña incorrecta

        // Hacer clic en el botón "SIGN IN"
        driver.findElement(By.xpath("//button[span[text()='SIGN IN']]")).click();

        // Esperar que el mensaje de error "Invalid email or password" se muestre
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement errorMessage = wait.until(driver ->
            driver.findElement(By.xpath("//div[text()='Invalid email or password']"))
        );

        // Validar que el mensaje de error esté visible
        Assert.assertTrue(errorMessage.isDisplayed(), "No se mostró el mensaje de error por credenciales incorrectas.");
    }
    
    //Metodo planteado para validar credenciales en blanco
    @Test(groups = {"Functional"})
    public void TC_Login_03_BlankCredentials() {

        // Dejar los campos de correo y contraseña en blanco
        driver.findElement(By.name("email")).sendKeys(""); // Campo email vacío
        driver.findElement(By.name("password")).sendKeys(""); // Campo password vacío

        // Hacer clic en el botón "SIGN IN"
        driver.findElement(By.xpath("//button[span[text()='SIGN IN']]")).click();

     // Esperar a que aparezca el mensaje de error para el campo de correo
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement errorMessage = wait.until(driver ->
            driver.findElement(By.xpath("//span[text()='This field can not be empty']"))
        );

        // Validar que el mensaje de error esté visible para ambos campos
        Assert.assertTrue(errorMessage.isDisplayed(), "No se mostró el mensaje de error para los campos vacíos.");
    }
    
    //Metodo planteado para validar correo electronico no registrado
    @Test(groups = {"Functional"})
    public void TC_Login_04_UnregisteredEmail() {

        // Ingresar correo que no está registrado
        driver.findElement(By.name("email")).sendKeys("prueba1234@gmail.com");

        // Ingresar una contraseña válida (aunque no importa mucho en este caso)
        driver.findElement(By.name("password")).sendKeys("prueba123");

        // Clic en el botón SIGN IN
        driver.findElement(By.xpath("//button[span[text()='SIGN IN']]")).click();

        // Esperar que aparezca el mensaje de error
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement errorMessage = wait.until(driver ->
            driver.findElement(By.xpath("//div[text()='Invalid email or password']"))
        );

        // Validar que el mensaje esté visible
        Assert.assertTrue(errorMessage.isDisplayed(), "No se mostró el mensaje de error por correo no registrado.");
    }
    
    @Test(groups = {"Functional"})
    public void TC_Login_05_ForgotPasswordLink() {

    	LoginPage loginPage = new LoginPage(driver);
        loginPage.clickForgotPassword();

        driver.findElement(By.name("email")).sendKeys("PedroGarcia@gmail.com");
        driver.findElement(By.xpath("//button[span[text()='RESET PASSWORD']]")).click();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement confirmation = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.cssSelector("p.text-success")
        ));

        Assert.assertTrue(confirmation.getText().contains("We have sent you an email"), 
            "El mensaje de confirmación no se mostró.");
        
    }

}