package tests;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class RegisterTests extends BaseTest {

	
	// Anotación que indica que este es un método de prueba
	@Test
	public void TC_Register_01_RegistroExitoso() {
		
		//Buscar el h1
		WebElement heading = driver.findElement(By.tagName("h1"));
		

		// Título esperado después de registrarse correctamente
		String actualHeadingText = heading.getText();
		String expectedHeadingText = "Your Heading Here";
		
		// Navega hacia la URL base
		driver.get("https://demo.evershop.io/account/login");

		// Hacer clic en el enlace "Create an Account" del menú
		driver.findElement(By.linkText("Create an account")).click();

		// Llenar el campo "Full Name" con "Juan"
		driver.findElement(By.cssSelector("input[name='full_name']")).sendKeys("Carlos");

		// Llenar el campo de email con "juanperio25@yahoo.com"
		driver.findElement(By.xpath("//input[@name='email']")).sendKeys("carlosquiroz@gmail.com");

		// Llenar el campo "Password" con una contraseña segura
		driver.findElement(By.name("password")).sendKeys("carlitos123$");


		// Hacer clic en el botón "SIGN UP" (submit del formulario)
		driver.findElement(By.xpath("//button[span[text()='SIGN UP']]")).click();
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		// Verificar que el registro fue exitoso comprobando que el título sea "My Account"
		
		Assert.assertEquals(actualHeadingText, expectedHeadingText, "El encabezado no es el esperado.");


	}

	// Método comentado, planeado para probar registro con campos obligatorios faltantes
	@Test
	public void TC_Register_02_CamposObligatoriosVacios() {
		
	    // Click en "Create an Account"
	    driver.findElement(By.linkText("Create an account")).click();

	    //Click en el botón "SIGN UP"
	    driver.findElement(By.xpath("//button[span[text()='SIGN UP']]")).click();

	 // Esperamos a que aparezcan los mensajes de error en los <span>
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    List<WebElement> errorMessages = wait.until(driver ->
	        driver.findElements(By.xpath("//span[text()='This field can not be empty']"))
	    );

	    // Validamos que aparecieron los 3 errores (Full Name, Email y Password)
	    Assert.assertEquals(errorMessages.size(), 3, "No se mostraron los 3 mensajes de error esperados.");
	}
	
	// Método comwentado, planeado para probar formato de correo electonico valido
	@Test
	public void TC_Register_03_EmailInvalido() {
		
		// Click en "Create an account"
		driver.findElement(By.linkText("Create an account")).click();
		
		// Llenar campos, dejando el email en formato inválido
	    driver.findElement(By.name("full_name")).sendKeys("Carlos");
	    driver.findElement(By.name("email")).sendKeys("correo-invalido"); // <- sin @
	    driver.findElement(By.name("password")).sendKeys("Password123$");

	    // Hacer clic en "SIGN UP"
	    driver.findElement(By.xpath("//button[span[text()='SIGN UP']]")).click();

	    // Esperar que aparezca el mensaje de error
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    
	    WebElement emailFormatError = wait.until(driver ->
	        driver.findElement(By.xpath("//span[text()='Invalid email']"))
	    );

	    // Validar que el mensaje está visible
	    Assert.assertTrue(emailFormatError.isDisplayed(), "No se mostró el mensaje de error por email inválido.");	
	}
	
	
	//Metodo planteado para valññidar contraseña segura
	@Test
	public void TC_Register_04_ContrasenaInsegura() {

	    // Ir a "Create an account"
	    driver.findElement(By.linkText("Create an account")).click();

	    // Llenar los campos, pero con una contraseña inválida (menos de 6 caracteres)
	    driver.findElement(By.name("full_name")).sendKeys("Carlos");
	    driver.findElement(By.name("email")).sendKeys("correo@example.com");
	    driver.findElement(By.name("password")).sendKeys("123"); // Muy corta

	    // Clic en SIGN UP
	    driver.findElement(By.xpath("//button[span[text()='SIGN UP']]")).click();

	    // Esperar a que aparezca el mensaje de error
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    WebElement passwordError = wait.until(driver ->
	        driver.findElement(By.xpath("//div[text()='Password is invalid: Password must be at least 6 characters']"))
	    );

	    // Validar que el mensaje se muestra
	    Assert.assertTrue(passwordError.isDisplayed(), "No se mostró el mensaje de error por contraseña inválida.");
	}
	
	@Test
	public void vTC_Register_05_ConfirmacionNoCoincide() {
	    // Navegar al login
	    driver.get("https://demo.evershop.io/account/login");

	    // Clic en "Create an account"
	    driver.findElement(By.linkText("Create an account")).click();

	    // Llenar formulario con un correo que ya esté registrado
	    driver.findElement(By.name("full_name")).sendKeys("Carlos");
	    driver.findElement(By.name("email")).sendKeys("prueba123@gmail.com"); // <-- este debe estar ya registrado
	    driver.findElement(By.name("password")).sendKeys("Password123$");

	    // Clic en SIGN UP
	    driver.findElement(By.xpath("//button[span[text()='SIGN UP']]")).click();

	    // Esperar a que aparezca el mensaje de error
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    WebElement duplicateEmailError = wait.until(driver ->
	        driver.findElement(By.xpath("//div[text()='Email is already used']"))
	    );

	    // Validar que el mensaje se muestra correctamente
	    Assert.assertTrue(duplicateEmailError.isDisplayed(), "No se mostró el mensaje de error por correo duplicado.");
	}
	
	@Test(groups = {"Functional"})
	public void TC_Register_06_EmailYaRegistrado() {


	    // Hacer clic en el enlace "Forgot your password?"
	    driver.findElement(By.linkText("Forgot your password?")).click();

	    // Ingresar un correo válido o inventado
	    driver.findElement(By.name("email")).sendKeys("prueba123@gmail.copm");

	    // Clic en "Send reset link"
	    driver.findElement(By.xpath("//button[span[text()='RESET PASSWORD']]")).click();


	    // Esperar hasta que aparezca el mensaje de éxito
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    WebElement successMessage = wait.until(driver ->
	        driver.findElement(By.xpath("//p[contains(@class, 'text-success') and contains(text(), 'We have sent you an email with a link to reset your password. Please check your inbox.')]"))
	    );

	    // Validar el mensaje de éxito
	    String expectedMessage = "We have sent you an email with a link to reset your password. Please check your inbox.";
	    Assert.assertEquals(successMessage.getText(), expectedMessage, "El mensaje de éxito no es el esperado.");
	}
}