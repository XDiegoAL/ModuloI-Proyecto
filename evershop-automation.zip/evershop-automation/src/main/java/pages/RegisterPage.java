package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class RegisterPage extends BasePage {

    public RegisterPage(WebDriver driver) {
        super(driver);
    }

    By full_name = By.name("full_name");
    By email = By.name("email");
    By password = By.name("password");
    By registerBtn = By.xpath("//button[contains(text(),'Create an account')]");

    public void register(String name, String emailValue, String pass) {
        driver.findElement(full_name).sendKeys(name);
        driver.findElement(email).sendKeys(emailValue);
        driver.findElement(password).sendKeys(pass);
        driver.findElement(registerBtn).click();
    }
}