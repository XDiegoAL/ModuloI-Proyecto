package pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class OrderPage extends BasePage {

    public OrderPage(WebDriver driver) {
        super(driver);
    }

    By shopMen = By.xpath("//a[span[text()='Shop men']]");
    By selectItem = By.xpath("//a[@href='/men/nizza-trefoil-shoes-55']");
    By selectSize = By.xpath("//ul[contains(@class,'variant-option-list')]//a[text()='L']");
    By selectColor = By.xpath("//ul[contains(@class,'variant-option-list')]//a[text()='White']");
    By quantity = By.name("qty");
    By cartIcon = By.cssSelector("a[href='/cart']");
    By checkoutButton = By.xpath("//button[span[normalize-space()='ADD TO CART']]");
    By checkoutButton2 = By.xpath("//span[text()='CONTINUE SHOPPING']");
    By removeButton = By.xpath("//a[@class='text-textSubdued underline']/span[text()='Remove']");
    By increaseButton = By.cssSelector(".qty-box button:last-of-type");
    
    public void addProductToCart() {
    	
    	wait.until(ExpectedConditions.elementToBeClickable(shopMen)).click();
        driver.findElement(selectItem).click();
     // Seleccionar talla
        By sizeOption = By.xpath("//ul[contains(@class,'variant-option-list')]//a[text()='" + "M" + "']");
        wait.until(ExpectedConditions.elementToBeClickable(sizeOption)).click();
        wait.until(ExpectedConditions.urlContains("size="));

        // Seleccionar color
        By colorOption = By.xpath("//ul[contains(@class,'variant-option-list')]//a[text()='" + "White" + "']");
        wait.until(ExpectedConditions.elementToBeClickable(colorOption)).click();
        wait.until(ExpectedConditions.urlContains("color="));

        // Cambiar cantidad
        WebElement quantityField = driver.findElement(quantity);
        quantityField.sendKeys(Keys.chord(Keys.CONTROL, "a")); // selecciona todo
        quantityField.sendKeys("2"); // escribe la nueva cantidad
       
        wait.until(ExpectedConditions.elementToBeClickable(checkoutButton)).click();
        //driver.findElement(checkoutButton).click();
       
        }

    public void goToCartAndCheckout() {
    	wait.until(ExpectedConditions.elementToBeClickable(cartIcon)).click();
    }
    
    public void deleteProductFromCart(){
    	wait.until(ExpectedConditions.elementToBeClickable(removeButton)).click();
        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'cart-item')]")));
    }
    
    public boolean isProductInCart() {
        return driver.findElements(By.xpath("//div[contains(@class,'cart-item')]")).size() > 0;
    }
    
    public boolean isCartEmpty() {
        return driver.findElements(By.xpath("//div[contains(@class,'cart-item')]")).isEmpty();
    }
    
    public void updateProductQuantity(int newQuantity) {
    	
        WebElement qtyInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("qty")));
        
        qtyInput.clear();
        qtyInput.sendKeys(String.valueOf(newQuantity));
        qtyInput.sendKeys("\n"); 
        wait.until(ExpectedConditions.attributeToBe(qtyInput, "value", String.valueOf(newQuantity)));
    }
    public void increaseProductQuantity() {
    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

    	// Asegurarnos de que el contenedor del producto ya esté visible primero
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".cart-summary, .cart-items, .product-item")));

        // Ahora sí, esperamos el qty-box
        WebElement qtyBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".qty-box")));

        // Buscar el botón de incremento dentro del qty-box
        WebElement increaseButton = qtyBox.findElement(By.cssSelector("button:last-of-type"));

        // Esperar que sea clickable
        wait.until(ExpectedConditions.elementToBeClickable(increaseButton));

        // Scroll si es necesario
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", increaseButton);

        // Click
        increaseButton.click();

        System.out.println("Cantidad incrementada exitosamente.");
 
       
    }
}