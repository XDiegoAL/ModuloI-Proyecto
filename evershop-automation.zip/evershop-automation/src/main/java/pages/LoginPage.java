package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage extends BasePage {

    public LoginPage(WebDriver driver) {
        super(driver);
    }

    By email = By.name("email");
    By password = By.name("password");
    By loginButton = By.xpath("//button[span[text()='SIGN IN']]");
    By forgotPasswordLink = By.linkText("Forgot your password?");


    public void login(String userEmail, String userPassword) {
        driver.findElement(email).sendKeys(userEmail);
        driver.findElement(password).sendKeys(userPassword);
        driver.findElement(loginButton).click();
    }
    public void clickForgotPassword() {
        driver.findElement(forgotPasswordLink).click();
    }
}